 {{-- <div class="mb-1">
      <x-form.select :options="$revenueBusinessLines" :add-new="false" :label="__('Revenue Business Line')" class="select2-select revenue_business_line_class  " data-filter-type="{{ $type }}" :all="true" name="revenue_business_line_id" id="{{$type.'_'.'revenue_business_line_id' }}"  :selected-value="''" >
      </x-form.select>
</div>


 <div class="mb-1">
      <x-form.select :options="$serviceCategories" :add-new="false"  :label="__('Service Category')" class="select2-select service_category_class  " data-filter-type="{{ $type }}" :all="true" name="service_category_id" id="{{$type.'_'.'service_category_id' }}"  :selected-value="''" ></x-form.select>
</div>

 <div class="mb-1">
      <x-form.select :options="$serviceItems" :add-new="false"  :label="__('Service Item')" class="select2-select service_item_class  " data-filter-type="{{ $type }}" :all="true" name="service_item_id" id="{{$type.'_'.'service_item_id' }}"  :selected-value="''" ></x-form.select>
</div> --}}

                                         