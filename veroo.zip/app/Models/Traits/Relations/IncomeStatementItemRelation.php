<?php

namespace App\Models\Traits\Relations;

trait IncomeStatementItemRelation
{
	use FinancialStatementAbleItemRelation;
}
