<?php
namespace App\Interfaces\Models ;
interface IHaveCreator
{
    public function getCreatorName():string;
}