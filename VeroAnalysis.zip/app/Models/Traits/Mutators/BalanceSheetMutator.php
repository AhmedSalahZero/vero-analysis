<?php

namespace App\Models\Traits\Mutators;

trait BalanceSheetMutator
{
	use FinancialStatementAbleMutator;
}
