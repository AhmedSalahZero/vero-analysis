<?php

namespace App\Models\Traits\Mutators;

trait CashFlowStatementMutator
{
	use FinancialStatementAbleMutator;
}
