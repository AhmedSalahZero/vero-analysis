<?php

namespace App\Models\Traits\Mutators;


trait IncomeStatementMutator
{
	use FinancialStatementAbleMutator;
}
