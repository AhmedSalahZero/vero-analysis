<?php
namespace App\Interfaces\Models ;
interface IHaveName
{
    public function getName():string;
}