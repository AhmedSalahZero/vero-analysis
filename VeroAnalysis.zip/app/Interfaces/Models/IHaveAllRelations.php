<?php

namespace App\Interfaces\Models;

interface IHaveAllRelations
{
         public function getAllRelationsNames():array ;
}