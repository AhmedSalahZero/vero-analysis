<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AdjustedCollectionDatesFormLivewire extends Component
{
    public function render()
    {
        return view('livewire.adjusted-collection-dates-form-livewire');
    }
}
