<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.12.1/af-2.4.0/b-2.2.3/b-colvis-2.2.3/b-html5-2.2.3/b-print-2.2.3/cr-1.5.6/date-1.1.2/fc-4.1.0/fh-3.2.3/r-2.3.0/rg-1.2.0/sl-1.4.0/sr-1.1.1/datatables.min.css"/>
<style>
    table.dataTable thead tr > .dtfc-fixed-left, table.dataTable thead tr > .dtfc-fixed-right{
        background-color:#086691 !important;
    }
    /* .dtfc-fixed-left:not(.active-style),  .dtfc-fixed-right:not(.active-style){
        background-color:white !important;
        color:black;
    }  */
    .secondary-row-color .dtfc-fixed-left ,
    .secondary-row-color .dtfc-fixed-right
    {
        background-color:antiquewhite !important;
        color:#595d6e !important;
    }
      .group-color > .dtfc-fixed-left,  .group-color > .dtfc-fixed-right{
        background-color:#086691 !important;
           color:white !important;
         }
    .dtfc-fixed-left , .dtfc-fixed-right{
        /* color:white !important; */
    }
    
    thead *{
        text-align:center !important;
    }
</style>
