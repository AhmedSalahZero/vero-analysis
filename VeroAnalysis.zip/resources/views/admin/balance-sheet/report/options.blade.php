
                              <div class="mb-1">
      <x-form.select :options="$interval" :add-new="false" :label="__('Interval View')" class="select2-select revenue_business_line_class  " data-filter-type="{{ $type }}" :all="false" name="interval_view" id="{{$type.'_'.'interval_view' }}"  :selected-value="''" >
      </x-form.select>
</div>



                                         