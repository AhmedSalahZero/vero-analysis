<h2 {{ $attributes->merge(['class'=>'mb-3']) }}>
{{ $slot }}
</h2>