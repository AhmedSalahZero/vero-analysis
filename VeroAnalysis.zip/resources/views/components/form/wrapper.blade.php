{{-- col-md-4 --}}
<div {{ $attributes->merge(['class'=>'']) }}>
{{ $slot }}
</div>