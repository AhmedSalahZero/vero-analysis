<span class="kt-input-icon__icon kt-input-icon__icon--right col-md-6" tabindex="0" class="btn btn-success" role="button" data-toggle="kt-popover" data-trigger="focus" data-html="true" title="{{__('Field Info')}}" data-content="{!!$title!!}" >
    <span><i class="fa fa-question text-primary"></i></span>
</span>
