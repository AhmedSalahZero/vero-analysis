<div class="kt-portlet">
    <div class="kt-portlet__foot">
        <div class="kt-form__actions">
            <div class="row">
                <div class="col-lg-6 kt-align-right">
                    <button type="submit" class="btn btn-primary download-btn">{{$displayName}}</button>
                </div>
            </div>
        </div>
    </div>
</div>
