<?php

namespace App\Models\Traits\Relations;

trait BalanceSheetItemRelation
{
	use FinancialStatementAbleItemRelation;
}
