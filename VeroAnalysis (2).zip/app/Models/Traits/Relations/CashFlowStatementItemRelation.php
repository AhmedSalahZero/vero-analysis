<?php

namespace App\Models\Traits\Relations;


trait CashFlowStatementItemRelation
{
	use FinancialStatementAbleItemRelation;
}
