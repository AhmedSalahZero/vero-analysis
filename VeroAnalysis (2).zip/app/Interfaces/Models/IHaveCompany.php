<?php
namespace App\Interfaces\Models ;
interface IHaveCompany
{
    public function getCompanyName():string;
}