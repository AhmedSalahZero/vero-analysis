<?php
namespace App\Interfaces\Models ; 
interface IHaveIdentifier
{
    public function getIdentifier():int|string;

}