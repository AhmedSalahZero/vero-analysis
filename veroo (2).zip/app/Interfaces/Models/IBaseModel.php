<?php

namespace App\Interfaces\Models;

interface IBaseModel
{
        public function getName():string ; 
}